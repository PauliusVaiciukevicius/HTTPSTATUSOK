package tests;

import org.junit.jupiter.api.Test;
import pageobjects.LoginPage;
import pageobjects.MainPage;
import pageobjects.RegisterPage;

import java.util.Random;

public class LoginTest extends BaseTestLogin {
    MainPage mainPage;
    RegisterPage registerPage;
    LoginPage loginPage;

    @Test
    void userCanLogin() {
        mainPage = new MainPage(driver);
        loginPage = new LoginPage(driver);

//        loginPage.goToLogin();
        loginPage.inputUsernameL("admin");
//        Random randomGeneratorP = new Random();
//        String password = randomGeneratorP.nextInt(1000) + "password";
        loginPage.inpuPasswordL("admin");
        loginPage.LogIn();

    }
}