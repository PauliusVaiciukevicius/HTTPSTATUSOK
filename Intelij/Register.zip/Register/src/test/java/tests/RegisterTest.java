package tests;

import org.junit.jupiter.api.Test;
import pageobjects.BasePage;
import pageobjects.MainPage;
import pageobjects.RegisterPage;

import java.util.Random;

public class RegisterTest extends BaseTest {
    MainPage mainPage;
    RegisterPage registerPage;
@Test
    void userCanRegister (){
    mainPage = new MainPage(driver);
    registerPage = new RegisterPage(driver);

    registerPage.inputName("Emilija");
    registerPage.inputUsername("Emilij8");
    Random randomGenerator = new Random();
    String mail = randomGenerator.nextInt(1000) + "cern@gmail.com";
    registerPage.inputEmail(mail);
    Random randomGeneratorP = new Random();
    String password = randomGeneratorP.nextInt(1000) + "password";
    registerPage.inpuPassword(password);
    registerPage.inpuPasswordR(password);
//    registerPage.clickCreateButton();

}
}
