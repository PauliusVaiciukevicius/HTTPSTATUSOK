package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MainPage extends BasePage {
//@FindBy(xpath = "//div[@class='card']//div[1]//div[1]//input[1]")
//private WebElement inputName;
    public MainPage(WebDriver driver) {
        super(driver);
    }

}
