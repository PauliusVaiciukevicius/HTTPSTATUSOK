package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class RegisterPage extends BasePage{

    @FindBy (xpath = "//div[@class='card']//div[1]//div[1]//input[1]")
    public WebElement enterName;

    @FindBy (xpath = "//div[@class='col-md-']//input[@id='custom-input']")
    public WebElement enterUsername;

    @FindBy (xpath = "//div[3]//div[1]//input[1]")
    public WebElement enterEmail;

    @FindBy (xpath = "//div[@class='row']//div[4]//div[1]//input[1]")
    public WebElement enterPassword;

    @FindBy (xpath = "//div[5]//div[1]//input[1]")
    public WebElement enterPasswordR;

    @FindBy (css = "#custom-button")
    private WebElement createButton;

    public RegisterPage (WebDriver driver){
        super(driver);
    }
    public void inputName(String name){
        enterName.sendKeys(name);
    }
    public void inputUsername(String name){
        enterUsername.sendKeys(name);
    }
    public void inputEmail(String name){
        enterEmail.sendKeys(name);
    }
    public void inpuPassword(String name){
        enterPassword.sendKeys(name);
    }
    public void inpuPasswordR(String name){
        enterPasswordR.sendKeys(name);
    }
    public void clickCreateButton(){
        createButton.click();
    }

}
